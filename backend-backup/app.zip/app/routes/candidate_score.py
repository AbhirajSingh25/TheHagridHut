from fastapi import APIRouter

from pydantic import BaseModel

from typing import Optional


router = APIRouter(
    prefix="/candidate-intelligence",
    tags=["Candidate Intelligence"],
)


class CandidateScoreRequest(BaseModel):

    ats_score: float

    jd_match_score: float

    interview_score: float

    communication_score: float

    confidence_score: float

    candidate_name: Optional[str] = (
        "Candidate"
    )

    target_role: Optional[str] = (
        "Not Specified"
    )


def normalize_score(
    score: float,
):

    return max(
        0,
        min(
            100,
            score,
        ),
    )


def get_candidate_tier(
    score: int,
):

    if score >= 90:

        return "Elite Candidate"

    if score >= 80:

        return "Strong Candidate"

    if score >= 70:

        return "Competitive Candidate"

    if score >= 55:

        return "Developing Candidate"

    return "Needs Improvement"


def get_hiring_recommendation(
    score: int,
):

    if score >= 90:

        return "Strongly Recommended"

    if score >= 80:

        return "Recommended"

    if score >= 70:

        return "Consider for Interview"

    if score >= 55:

        return "Potential"

    return "Needs Improvement"


def get_score_status(
    score: float,
):

    if score >= 85:

        return "Excellent"

    if score >= 70:

        return "Strong"

    if score >= 55:

        return "Moderate"

    return "Needs Improvement"


def build_summary(
    candidate_name: str,
    target_role: str,
    final_score: int,
    tier: str,
    strongest_area: str,
    weakest_area: str,
):

    if final_score >= 85:

        return (
            f"{candidate_name} demonstrates strong overall "
            f"readiness for the {target_role} role. "
            f"The candidate performs best in "
            f"{strongest_area.lower()} and should continue "
            f"improving {weakest_area.lower()} to strengthen "
            f"overall hiring potential."
        )

    if final_score >= 70:

        return (
            f"{candidate_name} is a competitive candidate "
            f"for the {target_role} role. "
            f"The strongest area is "
            f"{strongest_area.lower()}, while "
            f"{weakest_area.lower()} is the main area "
            f"requiring improvement."
        )

    if final_score >= 55:

        return (
            f"{candidate_name} shows potential for the "
            f"{target_role} role but requires targeted "
            f"improvement. The candidate should preserve "
            f"strength in {strongest_area.lower()} and focus "
            f"primarily on {weakest_area.lower()}."
        )

    return (
        f"{candidate_name} currently requires further "
        f"preparation before being considered strongly for "
        f"the {target_role} role. The highest-performing "
        f"area is {strongest_area.lower()}, while "
        f"{weakest_area.lower()} requires immediate focus."
    )


@router.post("/score")
def calculate_candidate_intelligence(
    data: CandidateScoreRequest,
):

    scores = {

        "Resume ATS":
            normalize_score(
                data.ats_score
            ),

        "JD Match":
            normalize_score(
                data.jd_match_score
            ),

        "Interview Performance":
            normalize_score(
                data.interview_score
            ),

        "Communication":
            normalize_score(
                data.communication_score
            ),

        "Confidence":
            normalize_score(
                data.confidence_score
            ),
    }


    weights = {

        "Resume ATS":
            0.20,

        "JD Match":
            0.20,

        "Interview Performance":
            0.30,

        "Communication":
            0.20,

        "Confidence":
            0.10,
    }


    weighted_breakdown = {}


    for area in scores:

        weighted_breakdown[
            area
        ] = round(

            scores[area]
            *
            weights[area],

            2,
        )


    final_score = round(

        sum(
            weighted_breakdown.values()
        )
    )


    strongest_area = max(
        scores,
        key=scores.get,
    )


    weakest_area = min(
        scores,
        key=scores.get,
    )


    ranked_areas = sorted(

        scores.items(),

        key=lambda item:
            item[1],

        reverse=True,
    )


    strengths = [

        {
            "area":
                area,

            "score":
                round(score),

            "status":
                get_score_status(
                    score
                ),
        }

        for area, score
        in ranked_areas[:2]
    ]


    improvement_areas = [

        {
            "area":
                area,

            "score":
                round(score),

            "status":
                get_score_status(
                    score
                ),
        }

        for area, score
        in ranked_areas[-2:]
    ]


    tier = (
        get_candidate_tier(
            final_score
        )
    )


    recommendation = (
        get_hiring_recommendation(
            final_score
        )
    )


    summary = build_summary(

        candidate_name=
            data.candidate_name
            or
            "Candidate",

        target_role=
            data.target_role
            or
            "target",

        final_score=
            final_score,

        tier=
            tier,

        strongest_area=
            strongest_area,

        weakest_area=
            weakest_area,
    )


    return {

        "success":
            True,

        "candidate_name":
            data.candidate_name,

        "target_role":
            data.target_role,

        "hiresense_score":
            final_score,

        "candidate_tier":
            tier,

        "hiring_recommendation":
            recommendation,

        "strongest_area":
            strongest_area,

        "weakest_area":
            weakest_area,

        "score_breakdown": {

            "ats_score":
                round(
                    scores[
                        "Resume ATS"
                    ]
                ),

            "jd_match_score":
                round(
                    scores[
                        "JD Match"
                    ]
                ),

            "interview_score":
                round(
                    scores[
                        "Interview Performance"
                    ]
                ),

            "communication_score":
                round(
                    scores[
                        "Communication"
                    ]
                ),

            "confidence_score":
                round(
                    scores[
                        "Confidence"
                    ]
                ),
        },

        "weighted_breakdown":
            weighted_breakdown,

        "strengths":
            strengths,

        "improvement_areas":
            improvement_areas,

        "ai_recruiter_summary":
            summary,
    }