from fastapi import APIRouter
from fastapi import Depends

from sqlalchemy.orm import Session

from app.database import get_db
from app.models import InterviewSession

import json

router = APIRouter()


@router.get("/api/recruiter-dashboard")
def recruiter_dashboard(
    db: Session = Depends(get_db)
):

    interviews = (

        db.query(
            InterviewSession
        )

        .order_by(
            InterviewSession.overall_score.desc()
        )

        .all()
    )

    results = []

    for interview in interviews:

        results.append({

            "name":
                f"Candidate {interview.id}",

            "role":
                interview.role,

            "score":
                interview.overall_score or 0,

            "status":
                (
                    "Recommended"
                    if (interview.overall_score or 0) >= 70
                    else "Review"
                )
        })

    return results


@router.get("/recruiter-insights")
def recruiter_insights(
    db: Session = Depends(get_db)
):

    interviews = (
        db.query(
            InterviewSession
        ).all()
    )

    if not interviews:

        return {

            "technical":
                "No interview data available.",

            "communication":
                "No communication analysis available.",

            "recommendation":
                "Conduct interviews to generate insights."
        }

    avg_score = int(

        sum(
            i.overall_score or 0
            for i in interviews
        ) / len(interviews)
    )

    return {

        "technical":
            f"Average candidate score is {avg_score}%",

        "communication":
            "Communication quality remains strong across recent interviews.",

        "recommendation":
            (
                "Proceed with top candidates scoring above 80%."
            )
    }