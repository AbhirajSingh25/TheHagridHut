from fastapi import APIRouter, UploadFile, File
import cv2
import mediapipe as mp
import numpy as np
import tempfile
import os

router = APIRouter()

mp_face = mp.solutions.face_mesh

mesh = mp_face.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True
)


@router.post("/analyze-vision")
async def analyze(file: UploadFile = File(...)):

    temp = tempfile.NamedTemporaryFile(delete=False, suffix=".jpg")

    temp.write(await file.read())

    temp.close()

    image = cv2.imread(temp.name)

    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    result = mesh.process(rgb)

    os.remove(temp.name)

    if not result.multi_face_landmarks:

        return {

            "face_detected": False,

            "eye_contact": 0,

            "attention": 0,

            "confidence": 0,

            "smile": False
        }

    landmarks = result.multi_face_landmarks[0]

    left_eye = landmarks.landmark[33]

    right_eye = landmarks.landmark[263]

    nose = landmarks.landmark[1]

    eye_distance = abs(
        left_eye.x -
        right_eye.x
    )

    center = (
        left_eye.x +
        right_eye.x
    ) / 2

    eye_contact = int(
        max(
            0,
            100 -
            abs(center - 0.5) * 200
        )
    )

    attention = int(
        eye_contact * 0.9
    )

    confidence = int(
        (eye_contact + attention) / 2
    )

    return {

        "face_detected": True,

        "eye_contact": eye_contact,

        "attention": attention,

        "confidence": confidence,

        "smile": False,

        "nose_x": round(
            nose.x,
            3
        )
    }