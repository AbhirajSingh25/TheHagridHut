from fastapi import APIRouter
from fastapi import Depends

from sqlalchemy.orm import Session

from app.database import get_db
from app.models import InterviewSession

router = APIRouter()


@router.get("/admin/stats")
def admin_stats(
    db: Session = Depends(get_db)
):

    interviews = (
        db.query(
            InterviewSession
        ).all()
    )

    total_interviews = len(
        interviews
    )

    if total_interviews == 0:

        return {

            "total_interviews": 0,

            "average_score": 0,

            "recommended_candidates": 0,

            "top_score": 0,
        }

    scores = [

        i.overall_score or 0

        for i in interviews
    ]

    average_score = int(
        sum(scores)
        / len(scores)
    )

    recommended = len([

        s for s in scores

        if s >= 70
    ])

    return {

        "total_interviews":
            total_interviews,

        "average_score":
            average_score,

        "recommended_candidates":
            recommended,

        "top_score":
            max(scores),
    }