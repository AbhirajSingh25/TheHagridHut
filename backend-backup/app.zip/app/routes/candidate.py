from fastapi import APIRouter
from fastapi import Depends

from sqlalchemy.orm import Session

from app.database import get_db
from app.models import InterviewSession

import json

router = APIRouter()


@router.get("/candidate/intelligence")
def candidate_intelligence(
    db: Session = Depends(get_db)
):

    latest = (
        db.query(InterviewSession)
        .order_by(
            InterviewSession.id.desc()
        )
        .first()
    )

    if not latest:

        return {

            "overall": 0,

            "resume": 0,

            "jd_match": 0,

            "technical": 0,

            "communication": 0,

            "confidence": 0,

            "speech": 0,

            "behavior": 0,

            "recommendation":
                "No Interview Found",

            "salary_prediction":
                "N/A"
        }

    communication = 0
    technical = 0
    confidence = 0

    try:

        evaluations = json.loads(
            latest.evaluations
        )

        last = evaluations[-1]

        communication = last.get(
            "communication",
            0
        )

        technical = last.get(
            "technical",
            0
        )

        confidence = last.get(
            "confidence",
            0
        )

    except Exception:
        pass


    resume_score = 88
    jd_match = 85
    speech = confidence

    overall = round(

        (
            resume_score +
            jd_match +
            technical +
            communication +
            confidence +
            speech
        ) / 6

    )

    recommendation = (
        "Hire Immediately"
        if overall >= 90
        else
        "Recommended"
        if overall >= 75
        else
        "Needs Improvement"
    )

    salary = (
        "₹18-24 LPA"
        if overall >= 90
        else
        "₹10-18 LPA"
        if overall >= 75
        else
        "₹5-10 LPA"
    )

    return {

        "overall":
            overall,

        "resume":
            resume_score,

        "jd_match":
            jd_match,

        "technical":
            technical,

        "communication":
            communication,

        "confidence":
            confidence,

        "speech":
            speech,

        "behavior":
            communication,

        "recommendation":
            recommendation,

        "salary_prediction":
            salary,
    }