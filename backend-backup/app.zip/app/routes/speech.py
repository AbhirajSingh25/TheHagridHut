import json
import os
import re
import tempfile

from fastapi import (
    APIRouter,
    File,
    HTTPException,
    UploadFile,
)

from groq import Groq

from app.config import GROQ_API_KEY


router = APIRouter(
    prefix="/speech",
    tags=["Speech Intelligence"],
)


client = Groq(
    api_key=GROQ_API_KEY
)


FILLER_WORDS = [
    "um",
    "uh",
    "umm",
    "uhh",
    "like",
    "you know",
    "actually",
    "basically",
    "literally",
    "sort of",
    "kind of",
]


ALLOWED_EXTENSIONS = {
    ".mp3",
    ".wav",
    ".m4a",
    ".webm",
    ".mp4",
    ".mpeg",
    ".mpga",
}


def detect_filler_words(
    text: str,
):

    lower_text = text.lower()

    filler_breakdown = {}

    total_fillers = 0


    for filler in FILLER_WORDS:

        pattern = (
            rf"\b{re.escape(filler)}\b"
        )

        count = len(
            re.findall(
                pattern,
                lower_text,
            )
        )


        if count > 0:

            filler_breakdown[
                filler
            ] = count

            total_fillers += count


    return (
        total_fillers,
        filler_breakdown,
    )


def calculate_wpm(
    text: str,
    duration_seconds: float,
):

    word_count = len(
        text.split()
    )


    if duration_seconds <= 0:

        return 0


    duration_minutes = (
        duration_seconds / 60
    )


    return round(
        word_count
        /
        duration_minutes
    )


def calculate_pacing_score(
    wpm: int,
):

    if 110 <= wpm <= 160:

        return 100


    if 90 <= wpm < 110:

        return 85


    if 160 < wpm <= 180:

        return 85


    if 70 <= wpm < 90:

        return 70


    if 180 < wpm <= 200:

        return 65


    return 45


def calculate_filler_score(
    filler_count: int,
    word_count: int,
):

    if word_count == 0:

        return 0


    filler_ratio = (
        filler_count
        /
        word_count
    )


    if filler_ratio <= 0.01:

        return 100


    if filler_ratio <= 0.03:

        return 90


    if filler_ratio <= 0.05:

        return 75


    if filler_ratio <= 0.08:

        return 60


    return 40


def calculate_base_confidence(
    pacing_score: int,
    filler_score: int,
):

    score = (
        pacing_score * 0.45
        +
        filler_score * 0.55
    )


    return round(
        score
    )


def clean_json_response(
    raw_response: str,
):

    cleaned = (
        raw_response
        .strip()
    )


    if cleaned.startswith(
        "```json"
    ):

        cleaned = cleaned[7:]


    elif cleaned.startswith(
        "```"
    ):

        cleaned = cleaned[3:]


    if cleaned.endswith(
        "```"
    ):

        cleaned = cleaned[:-3]


    return cleaned.strip()


def safe_score(
    value,
    default=0,
):

    try:

        score = int(
            value
        )


        return max(
            0,
            min(
                100,
                score,
            ),
        )


    except Exception:

        return default


def get_value(
    data,
    key: str,
    default=None,
):

    if isinstance(
        data,
        dict,
    ):

        return data.get(
            key,
            default,
        )


    return getattr(
        data,
        key,
        default,
    )


def transcribe_with_groq(
    file_path: str,
    filename: str,
):

    with open(
        file_path,
        "rb",
    ) as audio_file:

        transcription = (
            client
            .audio
            .transcriptions
            .create(
                file=(
                    filename,
                    audio_file.read(),
                ),

                model=(
                    "whisper-large-v3-turbo"
                ),

                response_format=(
                    "verbose_json"
                ),

                temperature=0.0,
            )
        )


    transcript = (
        get_value(
            transcription,
            "text",
            "",
        )
        or ""
    ).strip()


    duration_seconds = (
        get_value(
            transcription,
            "duration",
            0,
        )
        or 0
    )


    try:

        duration_seconds = float(
            duration_seconds
        )

    except Exception:

        duration_seconds = 0


    return (
        transcript,
        duration_seconds,
    )


def analyze_with_groq(
    transcript: str,
    wpm: int,
    filler_count: int,
    pacing_score: int,
    base_confidence: int,
):

    system_prompt = """
You are a senior technical recruiter and interview communication coach.

Analyze a candidate's spoken interview response.

Evaluate communication quality.

Consider:

1. Clarity
2. Grammar
3. Professionalism
4. Confidence
5. Structure
6. Conciseness
7. Communication effectiveness

Return ONLY valid JSON.

Use exactly this structure:

{
    "communication_score": 85,
    "confidence_score": 82,
    "clarity_score": 88,
    "grammar_score": 84,
    "professionalism_score": 90,
    "clarity": "Very Good",
    "grammar": "Good",
    "professionalism": "High",
    "sentiment": "Confident",
    "answer_structure": "Well Structured",
    "strengths": [
        "Clear explanation",
        "Professional vocabulary"
    ],
    "improvements": [
        "Reduce repetition",
        "Use shorter sentences"
    ],
    "recruiter_feedback": "The candidate communicates clearly and professionally.",
    "hire_recommendation": "Recommended"
}

Rules:

All numeric scores must be integers from 0 to 100.

strengths must contain 2 to 4 useful points.

improvements must contain 2 to 4 useful points.

recruiter_feedback must be concise.

hire_recommendation must be one of:

"Strongly Recommended"
"Recommended"
"Potential"
"Needs Improvement"

Return ONLY JSON.

No markdown.

No code blocks.

No explanation outside JSON.
"""


    user_prompt = f"""
Candidate Transcript:

{transcript}


Objective Speech Metrics:

Speaking Speed:
{wpm} words per minute

Filler Words:
{filler_count}

Pacing Score:
{pacing_score}/100

Base Confidence Score:
{base_confidence}/100


Analyze the candidate's communication performance.
"""


    completion = (
        client
        .chat
        .completions
        .create(
            model=(
                "llama-3.3-70b-versatile"
            ),

            temperature=0.2,

            messages=[

                {
                    "role":
                        "system",

                    "content":
                        system_prompt,
                },

                {
                    "role":
                        "user",

                    "content":
                        user_prompt,
                },
            ],
        )
    )


    raw_response = (
        completion
        .choices[0]
        .message
        .content
    )


    cleaned_response = (
        clean_json_response(
            raw_response
        )
    )


    return json.loads(
        cleaned_response
    )


@router.post("/analyze")
async def analyze_speech(
    file: UploadFile = File(...),
):

    temp_path = None


    try:

        original_filename = (
            file.filename
            or
            "interview_audio.webm"
        )


        extension = (
            os.path.splitext(
                original_filename
            )[1]
            .lower()
        )


        if (
            extension
            not in ALLOWED_EXTENSIONS
        ):

            extension = ".webm"


        contents = (
            await file.read()
        )


        if not contents:

            raise HTTPException(
                status_code=400,

                detail=(
                    "Uploaded audio file is empty."
                ),
            )


        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=extension,
        ) as temp_file:

            temp_file.write(
                contents
            )

            temp_path = (
                temp_file.name
            )


        (
            transcript,
            duration_seconds,
        ) = transcribe_with_groq(
            file_path=
                temp_path,

            filename=
                original_filename,
        )


        if not transcript:

            raise HTTPException(
                status_code=400,

                detail=(
                    "No speech could be detected in the audio."
                ),
            )


        word_count = len(
            transcript.split()
        )


        wpm = calculate_wpm(
            transcript,
            duration_seconds,
        )


        (
            filler_count,
            filler_breakdown,
        ) = detect_filler_words(
            transcript
        )


        pacing_score = (
            calculate_pacing_score(
                wpm
            )
        )


        filler_score = (
            calculate_filler_score(
                filler_count,
                word_count,
            )
        )


        base_confidence = (
            calculate_base_confidence(
                pacing_score,
                filler_score,
            )
        )


        try:

            ai_review = (
                analyze_with_groq(
                    transcript=
                        transcript,

                    wpm=
                        wpm,

                    filler_count=
                        filler_count,

                    pacing_score=
                        pacing_score,

                    base_confidence=
                        base_confidence,
                )
            )


        except Exception as ai_error:

            print(
                "Recruiter AI analysis error:",
                ai_error,
            )


            ai_review = {

                "communication_score":
                    round(
                        (
                            pacing_score
                            +
                            filler_score
                        )
                        /
                        2
                    ),

                "confidence_score":
                    base_confidence,

                "clarity_score":
                    70,

                "grammar_score":
                    70,

                "professionalism_score":
                    70,

                "clarity":
                    "Good",

                "grammar":
                    "Good",

                "professionalism":
                    "Good",

                "sentiment":
                    "Neutral",

                "answer_structure":
                    "Average",

                "strengths": [
                    "Completed the spoken response"
                ],

                "improvements": [
                    "Continue improving answer structure"
                ],

                "recruiter_feedback":
                    (
                        "Speech metrics were analyzed successfully."
                    ),

                "hire_recommendation":
                    "Potential",
            }


        communication_score = (
            safe_score(
                ai_review.get(
                    "communication_score"
                ),
                70,
            )
        )


        confidence_score = (
            safe_score(
                ai_review.get(
                    "confidence_score"
                ),
                base_confidence,
            )
        )


        clarity_score = (
            safe_score(
                ai_review.get(
                    "clarity_score"
                ),
                70,
            )
        )


        grammar_score = (
            safe_score(
                ai_review.get(
                    "grammar_score"
                ),
                70,
            )
        )


        professionalism_score = (
            safe_score(
                ai_review.get(
                    "professionalism_score"
                ),
                70,
            )
        )


        return {

            "success":
                True,

            "transcript":
                transcript,

            "speech_metrics": {

                "duration_seconds":
                    round(
                        duration_seconds,
                        2,
                    ),

                "word_count":
                    word_count,

                "wpm":
                    wpm,

                "filler_words":
                    filler_count,

                "filler_breakdown":
                    filler_breakdown,

                "pacing_score":
                    pacing_score,

                "filler_score":
                    filler_score,
            },

            "ai_scores": {

                "communication_score":
                    communication_score,

                "confidence_score":
                    confidence_score,

                "clarity_score":
                    clarity_score,

                "grammar_score":
                    grammar_score,

                "professionalism_score":
                    professionalism_score,
            },

            "analysis": {

                "clarity":
                    ai_review.get(
                        "clarity",
                        "Good",
                    ),

                "grammar":
                    ai_review.get(
                        "grammar",
                        "Good",
                    ),

                "professionalism":
                    ai_review.get(
                        "professionalism",
                        "Good",
                    ),

                "sentiment":
                    ai_review.get(
                        "sentiment",
                        "Neutral",
                    ),

                "answer_structure":
                    ai_review.get(
                        "answer_structure",
                        "Average",
                    ),
            },

            "strengths":
                ai_review.get(
                    "strengths",
                    [],
                ),

            "improvements":
                ai_review.get(
                    "improvements",
                    [],
                ),

            "recruiter_feedback":
                ai_review.get(
                    "recruiter_feedback",
                    "",
                ),

            "hire_recommendation":
                ai_review.get(
                    "hire_recommendation",
                    "Potential",
                ),
        }


    except HTTPException:

        raise


    except Exception as error:

        print(
            "Speech analysis error:",
            error,
        )


        raise HTTPException(
            status_code=500,

            detail=(
                "Speech analysis failed: "
                f"{str(error)}"
            ),
        )


    finally:

        if (
            temp_path
            and
            os.path.exists(
                temp_path
            )
        ):

            try:

                os.remove(
                    temp_path
                )


            except Exception:

                pass