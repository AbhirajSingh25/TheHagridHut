from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from groq import Groq

from app.config import GROQ_API_KEY
from app.database import get_db
from app.models import InterviewSession

import json

router = APIRouter()

client = Groq(
    api_key=GROQ_API_KEY
)


# ==================================================
# REQUEST MODELS
# ==================================================

class EvaluationRequest(BaseModel):

    question: str

    answer: str

    speech_metrics: dict = {}


class FollowupRequest(BaseModel):
    question: str
    answer: str
    role: str
    level: str


class InterviewSaveRequest(BaseModel):

    role: str

    level: str

    questions: list

    answers: list

    evaluations: list

    final_report: dict | None = None

    resume_score: int = 0

    jd_match_score: int = 0

    speech_score: int = 0

    filler_words: int = 0

    speaking_speed: float = 0

    pause_score: int = 0

    pronunciation_score: int = 0

    hiring_probability: int = 0

    candidate_score: int = 0

    recruiter_recommendation: str = ""

    expected_salary: str = ""

    certificate_id: str = ""


# ==================================================
# EVALUATE ANSWER
# ==================================================

@router.post("/evaluate-answer")
async def evaluate_answer(
    data: EvaluationRequest
):

    completion = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[

            {

                "role":"system",

                "content":"""
You are a Senior FAANG Technical Interviewer.

Evaluate BOTH:

1. Technical quality

2. Communication quality

3. Confidence

4. Professionalism

Use the supplied speech metrics.

Return ONLY JSON.

{

"technical":88,

"communication":91,

"confidence":87,

"professionalism":90,

"overall_score":89,

"strengths":[

"..."

],

"improvements":[

"..."

],

"feedback":"...",


"hire":"Hire"

}
"""

            },

            {

                "role":"user",

                "content":f"""

Question

{data.question}



Candidate Answer

{data.answer}



Speech Metrics

{json.dumps(data.speech_metrics,indent=2)}

"""

            }

        ]

    )

    try:

        return json.loads(

            completion

            .choices[0]

            .message

            .content

        )

    except:

        return{

            "technical":80,

            "communication":80,

            "confidence":80,

            "professionalism":80,

            "overall_score":80,

            "strengths":[],

            "improvements":[],

            "feedback":"",

            "hire":"Review"

        }


# ==================================================
# FOLLOWUP QUESTION
# ==================================================

@router.post("/generate-followup")
async def generate_followup(
    data: FollowupRequest
):

    completion = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[

            {
                "role": "system",

                "content": """
Generate ONE interview follow-up question.

Return ONLY the question.
"""
            },

            {
                "role": "user",

                "content": f"""
Role:
{data.role}

Level:
{data.level}

Question:
{data.question}

Answer:
{data.answer}
"""
            }
        ]
    )

    return {

        "question":

            completion
            .choices[0]
            .message
            .content
            .strip()
    }


# ==================================================
# GENERATE FINAL REPORT
# ==================================================

@router.post("/generate-report")
async def generate_report(
    data: InterviewSaveRequest
):

    completion = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[

            {
                "role": "system",

                "content": """
Return ONLY JSON.

{
    "overall_score":88,
    "communication":90,
    "technical":85,
    "confidence":87,
    "strengths":["Strong backend"],
    "weaknesses":["Cloud exposure"],
    "recommendation":"Proceed",
    "verdict":"Strong Candidate"
}
"""
            },

            {
                "role": "user",

                "content": f"""
Role:
{data.role}

Level:
{data.level}

Questions:
{data.questions}

Answers:
{data.answers}

Evaluations:
{data.evaluations}
"""
            }
        ]
    )

    try:

        return json.loads(
            completion.choices[0].message.content
        )

    except Exception:

        return {

            "overall_score": 80,

            "communication": 80,

            "technical": 80,

            "confidence": 80,

            "strengths": [],

            "weaknesses": [],

            "recommendation":
                "Review Required",

            "verdict":
                "Unable To Generate"
        }


# ==================================================
# SAVE INTERVIEW
# ==================================================

@router.post("/save-interview")
async def save_interview(
    data: InterviewSaveRequest,
    db: Session = Depends(get_db)
):

    scores = [

        item.get(
            "overall_score",
            0
        )

        for item in data.evaluations
    ]

    technical_scores = [

        item.get(
            "technical",
            0
        )

        for item in data.evaluations
    ]

    communication_scores = [

        item.get(
            "communication",
            0
        )

        for item in data.evaluations
    ]

    confidence_scores = [

        item.get(
            "confidence",
            0
        )

        for item in data.evaluations
    ]

    overall_score = (
        int(sum(scores) / len(scores))
        if scores
        else 0
    )

    technical_score = (
        int(sum(technical_scores) / len(technical_scores))
        if technical_scores
        else 0
    )

    communication_score = (
        int(sum(communication_scores) / len(communication_scores))
        if communication_scores
        else 0
    )

    confidence_score = (
        int(sum(confidence_scores) / len(confidence_scores))
        if confidence_scores
        else 0
    )

    session = InterviewSession(

        role=data.role,

        level=data.level,

        questions=json.dumps(data.questions),

        answers=json.dumps(data.answers),

        evaluations=json.dumps(data.evaluations),

        final_report=(
            json.dumps(data.final_report)
            if data.final_report
            else ""
        ),

        overall_score=overall_score,

        technical_score=technical_score,

        communication_score=communication_score,

        confidence_score=confidence_score,

        resume_score=data.resume_score,

        jd_match_score=data.jd_match_score,

        speech_score=data.speech_score,

        filler_words=data.filler_words,

        speaking_speed=data.speaking_speed,

        pause_score=data.pause_score,

        pronunciation_score=data.pronunciation_score,

        hiring_probability=data.hiring_probability,

        candidate_score=data.candidate_score,

        recruiter_recommendation=data.recruiter_recommendation,

        expected_salary=data.expected_salary,

        certificate_id=data.certificate_id,
    )

    db.add(session)

    db.commit()

    db.refresh(session)

    return {

        "success": True,

        "session_id": session.id,

        "overall_score": overall_score
    }


# ==================================================
# INTERVIEW HISTORY
# ==================================================

@router.get("/history")
async def get_history(
    db: Session = Depends(get_db)
):

    interviews = (

        db.query(
            InterviewSession
        )

        .order_by(
            InterviewSession.id.desc()
        )

        .all()
    )

    return interviews


# ==================================================
# LATEST REPORT
# ==================================================

@router.get("/latest-report")
async def latest_report(
    db: Session = Depends(get_db)
):

    session = (

        db.query(
            InterviewSession
        )

        .order_by(
            InterviewSession.id.desc()
        )

        .first()
    )

    if not session:

        return None

    return {

        "id":
            session.id,

        "role":
            session.role,

        "level":
            session.level,

        "overall_score":
            session.overall_score,

        "questions":
            json.loads(
                session.questions
            ),

        "answers":
            json.loads(
                session.answers
            ),

        "evaluations":
            json.loads(
                session.evaluations
            ),

        "created_at":
            str(
                session.created_at
            )
    }


# ==================================================
# SESSION DETAILS
# ==================================================

@router.get("/session/{session_id}")
async def get_session(
    session_id: int,
    db: Session = Depends(get_db)
):

    session = (

        db.query(
            InterviewSession
        )

        .filter(
            InterviewSession.id == session_id
        )

        .first()
    )

    if not session:

        return {
            "error":
                "Session not found"
        }

    return {

        "id":
            session.id,

        "role":
            session.role,

        "level":
            session.level,

        "overall_score":
            session.overall_score,

        "questions":
            json.loads(
                session.questions
            ),

        "answers":
            json.loads(
                session.answers
            ),

        "evaluations":
            json.loads(
                session.evaluations
            ),

        "created_at":
            str(
                session.created_at
            )
    }
@router.get("/playback/{session_id}")
async def playback(
    session_id: int,
    db: Session = Depends(get_db)
):

    session = (

        db.query(
            InterviewSession
        )

        .filter(
            InterviewSession.id == session_id
        )

        .first()
    )

    if not session:

        return {
            "error":
                "Session not found"
        }

    return {

        "role":
            session.role,

        "level":
            session.level,

        "overall_score":
            session.overall_score,

        "questions":
            json.loads(
                session.questions
            ),

        "answers":
            json.loads(
                session.answers
            ),

        "evaluations":
            json.loads(
                session.evaluations
            ),

        "created_at":
            str(
                session.created_at
            )
    }