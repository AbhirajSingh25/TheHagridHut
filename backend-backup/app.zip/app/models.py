from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    DateTime,
    Float,
)

from datetime import datetime

from app.database import Base


class User(Base):

    __tablename__ = "users"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    username = Column(
        String,
        unique=True
    )

    email = Column(
        String,
        unique=True
    )

    password = Column(
        String
    )


class InterviewSession(Base):

    __tablename__ = "interview_sessions"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    # =====================
    # INTERVIEW DETAILS
    # =====================

    role = Column(String)

    level = Column(String)

    questions = Column(Text)

    answers = Column(Text)

    evaluations = Column(Text)

    final_report = Column(Text)

    overall_score = Column(Integer)

    # =====================
    # RESUME AI
    # =====================

    resume_score = Column(
        Integer,
        default=0
    )

    jd_match_score = Column(
        Integer,
        default=0
    )

    # =====================
    # INTERVIEW AI
    # =====================

    technical_score = Column(
        Integer,
        default=0
    )

    communication_score = Column(
        Integer,
        default=0
    )

    confidence_score = Column(
        Integer,
        default=0
    )

    # =====================
    # SPEECH AI
    # =====================

    speech_score = Column(
        Integer,
        default=0
    )

    filler_words = Column(
        Integer,
        default=0
    )

    speaking_speed = Column(
        Float,
        default=0
    )

    pause_score = Column(
        Integer,
        default=0
    )

    pronunciation_score = Column(
        Integer,
        default=0
    )

    # =====================
    # VISION AI
    # =====================

    eye_contact_score = Column(
        Integer,
        default=0
    )

    emotion_score = Column(
        Integer,
        default=0
    )

    posture_score = Column(
        Integer,
        default=0
    )

    behavior_score = Column(
        Integer,
        default=0
    )

    # =====================
    # FINAL AI
    # =====================

    hiring_probability = Column(
        Integer,
        default=0
    )

    candidate_score = Column(
        Integer,
        default=0
    )

    recruiter_recommendation = Column(
        Text,
        default=""
    )

    expected_salary = Column(
        String,
        default=""
    )

    certificate_id = Column(
        String,
        default=""
    )

    # =====================

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )