import { motion } from "framer-motion";

type Props={

listening:boolean;

};

export default function AIOrb({

listening,

}:Props){

return(

<motion.div

animate={{

scale:listening

?

[1,1.08,1]

:

1,

}}

transition={{

repeat:Infinity,

duration:1.5,

}}

className="
relative
w-36
h-36
rounded-full
border-[10px]
border-red-500/20
flex
items-center
justify-center
"

>

<motion.div

animate={{

scale:listening

?

[1,0.8,1]

:

1,

}}

transition={{

repeat:Infinity,

duration:1,

}}

className="
w-14
h-14
rounded-full
bg-red-500
shadow-[0_0_80px_rgba(255,0,0,.6)]
"
/>

</motion.div>

);

}