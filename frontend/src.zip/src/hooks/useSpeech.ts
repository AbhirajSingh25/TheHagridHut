import { useRef, useState } from "react";
import { analyzeSpeech } from "../services/api";

export default function useSpeech() {

    const mediaRecorder =
        useRef<MediaRecorder | null>(null);

    const chunks =
        useRef<Blob[]>([]);

    const [recording, setRecording] =
        useState(false);

    const [processing, setProcessing] =
        useState(false);

    const [transcript, setTranscript] =
        useState("");

    const [speechData, setSpeechData] =
        useState<any>(null);

    async function startRecording() {

        const stream =
            await navigator.mediaDevices.getUserMedia({

                audio: true,

            });

        chunks.current = [];

        mediaRecorder.current =
            new MediaRecorder(stream);

        mediaRecorder.current.ondataavailable =
            (event) => {

                if (event.data.size > 0) {

                    chunks.current.push(event.data);

                }

            };

        mediaRecorder.current.start();

        setRecording(true);

    }

    async function stopRecording() {

        return new Promise<any>((resolve) => {

            if (!mediaRecorder.current) {

                resolve(null);

                return;

            }

            mediaRecorder.current.onstop =
                async () => {

                    setRecording(false);

                    setProcessing(true);

                    const blob =
                        new Blob(

                            chunks.current,

                            {

                                type: "audio/webm",

                            }

                        );

                    const formData =
                        new FormData();

                    formData.append(

                        "audio",

                        blob,

                        "speech.webm"

                    );

                    try {

                        const result =
                            await analyzeSpeech(

                                formData

                            );

                        setTranscript(

                            result.transcript

                        );

                        setSpeechData(

                            result

                        );

                        resolve(result);

                    }

                    finally {

                        setProcessing(false);

                    }

                };

            mediaRecorder.current.stop();

        });

    }

    function resetSpeech() {

        setTranscript("");

        setSpeechData(null);

    }

    return {

        recording,

        processing,

        transcript,

        speechData,

        startRecording,

        stopRecording,

        resetSpeech,

    };

}