import { useState } from "react";

import {
  generateQuestions,
  aiEvaluate,
  generateFollowupQuestion,
  generateInterviewReport,
  saveInterview,
} from "../services/api";

export default function useInterview() {

  const [role, setRole] =
    useState("Software Engineer");

  const [level, setLevel] =
    useState("Intermediate");

  const [questions, setQuestions] =
    useState<string[]>([]);

  const [currentQuestion, setCurrentQuestion] =
    useState(0);

  const [answers, setAnswers] =
    useState<string[]>([]);

  const [evaluations, setEvaluations] =
    useState<any[]>([]);

  const [loading, setLoading] =
    useState(false);

  const [started, setStarted] =
    useState(false);

  const [finished, setFinished] =
    useState(false);

  const [report, setReport] =
    useState<any>(null);

  async function startInterview() {

    setLoading(true);

    try {

      const response =
        await generateQuestions(
          role,
          level
        );

      setQuestions(
        response.questions
      );

      setStarted(true);

    }

    finally {

      setLoading(false);

    }

  }

  async function processSpeech(
    speechResult:any
  ){

    if(!speechResult)return;

    const answer =
      speechResult.transcript;

    const updatedAnswers=[
      ...answers,
      answer,
    ];

    setAnswers(
      updatedAnswers
    );

    const evaluation =
      await aiEvaluate(

        questions[currentQuestion],

        answer,

        speechResult.speech_metrics

      );

    const updatedEvaluations=[
      ...evaluations,
      evaluation,
    ];

    setEvaluations(
      updatedEvaluations
    );

    if(
      currentQuestion
      <
      questions.length-1
    ){

      const followup=
        await generateFollowupQuestion(

          questions[currentQuestion],

          answer,

          role,

          level

        );

      const updatedQuestions=[

        ...questions.slice(
          0,
          currentQuestion+1
        ),

        followup.question,

        ...questions.slice(
          currentQuestion+1
        )

      ];

      setQuestions(
        updatedQuestions
      );

      setCurrentQuestion(
        currentQuestion+1
      );

      return;

    }

    const finalReport=
      await generateInterviewReport({

        role,

        level,

        questions,

        answers:updatedAnswers,

        evaluations:updatedEvaluations,

      });

    await saveInterview({

      role,

      level,

      questions,

      answers:updatedAnswers,

      evaluations:updatedEvaluations,

      final_report:finalReport,

    } as any);

    setReport(
      finalReport
    );

    setFinished(true);

  }

  function nextQuestion(){

    if(
      currentQuestion
      <
      questions.length-1
    ){

      setCurrentQuestion(

        currentQuestion+1

      );

    }

  }

  return{

    role,
    setRole,

    level,
    setLevel,

    started,

    finished,

    loading,

    questions,

    currentQuestion,

    report,

    startInterview,

    processSpeech,

    nextQuestion,

  };

}