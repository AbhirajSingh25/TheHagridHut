import { useState } from "react";

import MainLayout from "../components/MainLayout";

function JDMatcher() {

  const [
    resumeText,
    setResumeText,
  ] = useState("");

  const [
    jobDescription,
    setJobDescription,
  ] = useState("");

  const [
    result,
    setResult,
  ] = useState<any>(null);

  const [
    loading,
    setLoading,
  ] = useState(false);

  async function analyze() {

    setLoading(true);

    try {

      const response =
        await fetch(

          "http://127.0.0.1:8000/api/resume/match-jd",

          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",
            },

            body: JSON.stringify({

              resume_text:
                resumeText,

              job_description:
                jobDescription,
            }),
          }
        );

      const data =
        await response.json();

      setResult(data);

    } catch (error) {

      console.error(error);
    }

    setLoading(false);
  }

  return (

    <MainLayout>

      <div className="max-w-7xl mx-auto">

        <h1
          className="
            text-6xl
            font-black
            mb-10
          "
        >
          Resume ↔ JD Matcher
        </h1>

        <div
          className="
            grid
            md:grid-cols-2
            gap-6
          "
        >

          <textarea
            className="
              bg-black/30
              border
              border-white/10
              rounded-2xl
              p-5
              h-[400px]
            "
            placeholder="Paste Resume Text"
            value={resumeText}
            onChange={(e) =>
              setResumeText(
                e.target.value
              )
            }
          />

          <textarea
            className="
              bg-black/30
              border
              border-white/10
              rounded-2xl
              p-5
              h-[400px]
            "
            placeholder="Paste Job Description"
            value={jobDescription}
            onChange={(e) =>
              setJobDescription(
                e.target.value
              )
            }
          />

        </div>

        <button
          onClick={analyze}
          className="
            mt-6
            h-14
            px-8
            rounded-2xl
            bg-red-500
            hover:bg-red-600
            font-bold
          "
        >
          {
            loading
              ? "Analyzing..."
              : "Match Resume"
          }
        </button>

        {

          result && (

            <div className="mt-10 space-y-6">

              <div
                className="
                  p-6
                  rounded-3xl
                  border
                  border-green-500/20
                  bg-green-500/5
                "
              >

                <h2
                  className="
                    text-4xl
                    font-black
                    text-green-400
                  "
                >
                  {
                    result.match_percentage
                  }%
                </h2>

                <p>
                  Match Percentage
                </p>

              </div>


              <div
                className="
                  p-6
                  rounded-3xl
                  border
                  border-white/10
                "
              >

                <h3
                  className="
                    text-2xl
                    font-bold
                    mb-4
                  "
                >
                  Missing Skills
                </h3>

                <div
                  className="
                    flex
                    flex-wrap
                    gap-3
                  "
                >

                  {
                    result.missing_skills?.map(
                      (
                        skill: string,
                        index: number
                      ) => (

                        <span
                          key={index}
                          className="
                            px-4
                            py-2
                            rounded-full
                            bg-red-500/10
                            text-red-400
                          "
                        >
                          {skill}
                        </span>

                      )
                    )
                  }

                </div>

              </div>


              <div
                className="
                  p-6
                  rounded-3xl
                  border
                  border-white/10
                "
              >

                <h3
                  className="
                    text-2xl
                    font-bold
                    mb-4
                  "
                >
                  Keywords To Add
                </h3>

                <div
                  className="
                    flex
                    flex-wrap
                    gap-3
                  "
                >

                  {
                    result.keywords_to_add?.map(
                      (
                        keyword: string,
                        index: number
                      ) => (

                        <span
                          key={index}
                          className="
                            px-4
                            py-2
                            rounded-full
                            bg-cyan-500/10
                            text-cyan-400
                          "
                        >
                          {keyword}
                        </span>

                      )
                    )
                  }

                </div>

              </div>


              <div
                className="
                  grid
                  md:grid-cols-2
                  gap-6
                "
              >

                <div
                  className="
                    p-6
                    rounded-3xl
                    border
                    border-green-500/20
                  "
                >

                  <h3
                    className="
                      text-2xl
                      font-bold
                      mb-4
                    "
                  >
                    Strengths
                  </h3>

                  <ul className="space-y-2">

                    {
                      result.strengths?.map(
                        (
                          item: string,
                          index: number
                        ) => (

                          <li key={index}>
                            • {item}
                          </li>

                        )
                      )
                    }

                  </ul>

                </div>


                <div
                  className="
                    p-6
                    rounded-3xl
                    border
                    border-yellow-500/20
                  "
                >

                  <h3
                    className="
                      text-2xl
                      font-bold
                      mb-4
                    "
                  >
                    Improvements
                  </h3>

                  <ul className="space-y-2">

                    {
                      result.improvements?.map(
                        (
                          item: string,
                          index: number
                        ) => (

                          <li key={index}>
                            • {item}
                          </li>

                        )
                      )
                    }

                  </ul>

                </div>

              </div>


              <div
                className="
                  p-6
                  rounded-3xl
                  bg-red-500/10
                  border
                  border-red-500/20
                "
              >

                <h2
                  className="
                    text-3xl
                    font-black
                    mb-2
                  "
                >
                  Hiring Recommendation
                </h2>

                <p
                  className="
                    text-xl
                    text-red-300
                  "
                >
                  {
                    result.hiring_recommendation
                  }
                </p>

              </div>

            </div>

          )
        }

      </div>

    </MainLayout>
  );
}

export default JDMatcher;