
import {

  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,

} from "recharts";
import {
  useEffect,
  useState,
} from "react";

import MainLayout from "../components/MainLayout";
import {
  motion,
} from "framer-motion";
import {
  getCandidateIntelligence,
} from "../services/api";

function CandidateIntelligence() {
const recruiterMessage=

"Candidate demonstrates excellent technical ability, strong communication, and consistent interview performance. Recommended for technical product companies.";

const[
typedMessage,
setTypedMessage
]=useState("");
  const [
    data,
    setData,
  ] = useState<any>(null);
useEffect(()=>{

let i=0;

const interval=

setInterval(()=>{

setTypedMessage(

recruiterMessage.slice(0,i)

);

i++;

if(i>

recruiterMessage.length){

clearInterval(interval);

}

},25);

return()=>clearInterval(interval);

},[]);
  useEffect(() => {

    load();

  }, []);

  async function load() {

    try {

      const result =
        await getCandidateIntelligence();

      setData(result);

    } catch (error) {

      console.error(error);

    }

  }

  return (

    <MainLayout>

      <div
  className="
    min-h-screen
    bg-black
    text-white
    relative
    overflow-hidden
  "
>

  {/* Animated Background */}

  <div
    className="
      absolute
      inset-0
      bg-[radial-gradient(circle_at_center,rgba(239,68,68,0.15),transparent_35%),radial-gradient(circle_at_top_right,rgba(6,182,212,0.12),transparent_40%),linear-gradient(to_bottom,#030303,#000000)]
    "
  />

  <div
    className="
      absolute
      inset-0
      opacity-20
      bg-[linear-gradient(rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.04)_1px,transparent_1px)]
      bg-[size:60px_60px]
    "
  />



  <div
    className="
      relative
      z-10
      max-w-7xl
      mx-auto
      px-8
      py-14
    "
  >
<motion.div

animate={{
rotate:360
}}

transition={{
duration:25,
repeat:Infinity,
ease:"linear"
}}

className="
absolute
right-0
top-10
w-[320px]
h-[320px]
rounded-full
border
border-red-500/20
"
/>
<motion.div

animate={{
y:[
-100,
2500
]
}}

transition={{
duration:5,
repeat:Infinity,
ease:"linear"
}}

className="
absolute
left-0
right-0
h-[3px]
bg-gradient-to-r
from-transparent
via-cyan-400
to-transparent
opacity-30
pointer-events-none
z-20
"
/>
{[...Array(20)].map((_,i)=>(

<motion.div

key={i}

animate={{

y:[0,-120,0],

x:[0,

Math.random()*80-40,

0]

}}

transition={{

duration:

5+

Math.random()*5,

repeat:Infinity

}}

className="
absolute
w-2
h-2
rounded-full
bg-cyan-400
opacity-30
"

style={{

left:`${Math.random()*100}%`,

top:`${Math.random()*100}%`

}}

/>

))}
<motion.div

animate={{
rotate:-360
}}

transition={{
duration:20,
repeat:Infinity,
ease:"linear"
}}

className="
absolute
right-16
top-24
w-[250px]
h-[250px]
rounded-full
border
border-cyan-500/20
"
/>

<motion.div

animate={{
scale:[1,1.1,1]
}}

transition={{
duration:4,
repeat:Infinity
}}

className="
absolute
right-[105px]
top-[110px]
w-32
h-32
rounded-full
bg-red-500
blur-[90px]
opacity-40
"
/>

      <p
        className="
          text-red-400
          tracking-[0.4em]
          uppercase
          mb-4
        "
      >
        AI Candidate Intelligence
      </p>

      <h1
        className="
          text-7xl
          font-black
          leading-none
        "
      >
        Complete Candidate
        <br/>

        Intelligence
      </h1>

      <p
        className="
          mt-8
          text-zinc-400
          text-xl
          max-w-3xl
        "
      >
        HireSense AI combines resume analysis,
        speech intelligence,
        interview performance,
        recruiter insights
        and behavioral analytics into
        one unified hiring score.
      </p>

  </div>

</div>
<div
className="
grid
grid-cols-4
gap-6
mt-20
"
>

<div>

<p className="text-zinc-500">
Overall Score
</p>

<h2
className="
text-6xl
font-black
text-red-400
"
>
{data?.overall ?? 0}
%
</h2>

</div>

<div>

<p className="text-zinc-500">
Resume
</p>

<h2
className="
text-5xl
font-bold
"
>
{data?.resume}
%
</h2>

</div>

<div>

<p className="text-zinc-500">
JD Match
</p>

<h2
className="
text-5xl
font-bold
"
>
{data?.jd_match}
%
</h2>

</div>

<div>

<p className="text-zinc-500">
Speech
</p>

<h2
className="
text-5xl
font-bold
"
>
{data?.speech}
%
</h2>

</div>

</div>
<div
  className="
    mt-24
    grid
    xl:grid-cols-2
    gap-8
  "
>

  {/* LEFT */}

  <motion.div

    initial={{
      opacity:0,
      x:-60
    }}

    whileInView={{
      opacity:1,
      x:0
    }}

    transition={{
      duration:0.7
    }}

    className="
      rounded-3xl
      border
      border-white/10
      bg-white/5
      backdrop-blur-xl
      p-8
    "
  >

    <h2
      className="
        text-3xl
        font-black
        mb-8
      "
    >
      Candidate Skills Radar
    </h2>

    <div
      className="
        h-[450px]
      "
    >

      <ResponsiveContainer>

        <RadarChart

          data={[

            {
              subject:"Resume",
              value:data?.resume || 0
            },

            {
              subject:"JD",
              value:data?.jd_match || 0
            },

            {
              subject:"Tech",
              value:data?.technical || 0
            },

            {
              subject:"Speech",
              value:data?.speech || 0
            },

            {
              subject:"Communication",
              value:data?.communication || 0
            },

            {
              subject:"Confidence",
              value:data?.confidence || 0
            },

          ]}

        >

          <PolarGrid />

          <PolarAngleAxis
            dataKey="subject"
          />

          <PolarRadiusAxis
            domain={[0,100]}
          />

          <Radar

            dataKey="value"

            stroke="#ef4444"

            fill="#ef4444"

            fillOpacity={0.55}

          />

        </RadarChart>

      </ResponsiveContainer>
          
    </div>

  </motion.div>

<motion.div

  initial={{
    opacity:0,
    x:60
  }}

  whileInView={{
    opacity:1,
    x:0
  }}

  transition={{
    duration:0.7
  }}

  className="
    rounded-3xl
    bg-white/5
    border
    border-white/10
    p-8
    backdrop-blur-xl
  "
>

  <p
    className="
      uppercase
      tracking-[0.35em]
      text-red-400
      text-sm
      mb-4
    "
  >
    Recruiter Verdict
  </p>

  <h2
    className="
      text-5xl
      font-black
      mb-6
    "
  >
    {data?.recommendation}
  </h2>

  <div
    className="
      flex
      gap-2
      text-yellow-400
      text-4xl
      mb-8
    "
  >
    ⭐⭐⭐⭐⭐
  </div>

  <div
    className="
      space-y-5
    "
  >

    <div
      className="
        p-5
        rounded-2xl
        bg-red-500/10
      "
    >

      Strong technical fundamentals.

    </div>

    <div
      className="
        p-5
        rounded-2xl
        bg-cyan-500/10
      "
    >

      Excellent communication skills.

    </div>

    <div
      className="
        p-5
        rounded-2xl
        bg-green-500/10
      "
    >

      High probability of successful hiring.

    </div>

  </div>

</motion.div>

</div>
<div
  className="
    mt-20
    flex
    justify-center
  "
>

<motion.div

animate={{
rotate:360
}}

transition={{
duration:18,
repeat:Infinity,
ease:"linear"
}}

className="
relative
w-72
h-72
rounded-full
border-[16px]
border-red-500
shadow-[0_0_80px_rgba(239,68,68,.25)]
flex
items-center
justify-center
"
>

<div
className="
text-center
"
>

<h1
className="
text-7xl
font-black
text-red-400
"
>

{data?.overall}%

</h1>

<p
className="
text-zinc-400
mt-2
"
>

Hire Probability

</p>

</div>

</motion.div>

</div>
<div
className="
mt-20
rounded-3xl
bg-gradient-to-r
from-red-500/20
to-cyan-500/20
border
border-white/10
p-10
"
>

<p
className="
uppercase
tracking-[0.35em]
text-zinc-400
mb-4
"
>

Salary Prediction

</p>

<h1
className="
text-6xl
font-black
"
>

{data?.salary_prediction}

</h1>

<p
className="
mt-6
text-zinc-400
"
>

Estimated compensation generated using
resume quality,
interview performance,
communication,
technical ability
and recruiter intelligence.

</p>

</div>
<motion.div

initial={{
opacity:0,
y:60
}}

whileInView={{
opacity:1,
y:0
}}

transition={{
duration:0.7
}}

className="
mt-20
rounded-3xl
bg-white/5
border
border-white/10
p-10
backdrop-blur-xl
"

>

<h2
className="
text-4xl
font-black
mb-10
"
>

AI Skill Heatmap

</h2>

{[
["Java",95],
["React",88],
["Python",91],
["SQL",82],
["Communication",93],
["Leadership",80],
["System Design",70],
["Problem Solving",94]
].map(([skill,score])=>(

<div
key={skill}
className="
mb-7
"
>

<div
className="
flex
justify-between
mb-2
"
>

<span
className="
font-semibold
"
>

{skill}

</span>

<span>

{score}%

</span>

</div>

<div
className="
h-4
rounded-full
bg-white/10
overflow-hidden
"
>

<motion.div

initial={{
width:0
}}

whileInView={{
width:`${score}%`
}}

transition={{
duration:1.2
}}

className="
h-full
rounded-full
bg-gradient-to-r
from-red-500
via-orange-400
to-cyan-400
"

/>

</div>

</div>

))}

</motion.div>
<motion.div

initial={{
opacity:0
}}

whileInView={{
opacity:1
}}

transition={{
duration:0.8
}}

className="
mt-20
rounded-3xl
bg-white/5
border
border-white/10
p-10
"

>

<h2
className="
text-4xl
font-black
mb-12
"
>

Candidate Journey

</h2>

<div
className="
space-y-8
"
>

{[

"Resume Uploaded",

"ATS Analysis Completed",

"JD Matching Completed",

"Interview Completed",

"Speech Intelligence",

"Candidate Intelligence Generated",

"Recruiter Recommendation Ready"

].map((step,index)=>(

<div

key={step}

className="
flex
items-center
gap-6
"

>

<div
className="
w-14
h-14
rounded-full
bg-red-500
flex
items-center
justify-center
font-black
"
>

{index+1}

</div>

<div>

<h3
className="
text-xl
font-bold
"
>

{step}

</h3>

</div>

</div>

))}
<div

className="
mt-24
rounded-3xl
bg-gradient-to-r
from-green-500/10
to-cyan-500/10
border
border-green-500/20
p-8
flex
justify-between
items-center
"

>

<div>

<h2
className="
text-2xl
font-black
"
>

AI Status

</h2>

<p
className="
text-zinc-400
"
>

All HireSense AI engines operational

</p>

</div>

<div
className="
flex
items-center
gap-3
text-green-400
font-bold
"
>

🟢 LIVE

</div>

</div>
</div>

</motion.div>
    </MainLayout>

  );

}

export default CandidateIntelligence;