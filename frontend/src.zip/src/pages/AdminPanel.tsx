import {
  useEffect,
  useState,
} from "react";

import MainLayout from "../components/MainLayout";

import {
  getAdminStats,
} from "../services/api";

function AdminPanel() {

  const [
    stats,
    setStats,
  ] = useState<any>(null);

  useEffect(() => {

    loadStats();

  }, []);

  async function loadStats() {

    const data =
      await getAdminStats();

    setStats(data);
  }

  if (!stats) {

    return (
      <MainLayout>
        Loading...
      </MainLayout>
    );
  }

  return (

    <MainLayout>

      <div className="max-w-7xl mx-auto">

        <h1
          className="
            text-6xl
            font-black
            mb-10
          "
        >
          Admin Panel
        </h1>

        <div
          className="
            grid
            md:grid-cols-4
            gap-6
          "
        >

          <div className="p-6 border rounded-3xl">
            <h2>
              {stats.total_interviews}
            </h2>
            <p>Total Interviews</p>
          </div>

          <div className="p-6 border rounded-3xl">
            <h2>
              {stats.average_score}%
            </h2>
            <p>Average Score</p>
          </div>

          <div className="p-6 border rounded-3xl">
            <h2>
              {stats.recommended_candidates}
            </h2>
            <p>Recommended</p>
          </div>

          <div className="p-6 border rounded-3xl">
            <h2>
              {stats.top_score}%
            </h2>
            <p>Top Score</p>
          </div>

        </div>

      </div>

    </MainLayout>
  );
}

export default AdminPanel;