import {
  useRef,
  useState,
} from "react";

import MainLayout from "../components/MainLayout";

import Card from "../components/ui/Card";

import {
  Activity,
  Brain,
  CheckCircle2,
  Clock3,
  FileAudio,
  Gauge,
  Mic,
  Play,
  RotateCcw,
  Sparkles,
  Square,
  Upload,
  Volume2,
  WandSparkles,
  XCircle,
} from "lucide-react";

import {
  analyzeSpeech,
} from "../services/api";


type SpeechResult = {

  success: boolean;

  transcript: string;

  speech_metrics: {

    duration_seconds: number;

    word_count: number;

    wpm: number;

    filler_words: number;

    filler_breakdown: {
      [key: string]: number;
    };

    pacing_score: number;

    filler_score: number;
  };

  ai_scores: {

    communication_score: number;

    confidence_score: number;

    clarity_score: number;

    grammar_score: number;

    professionalism_score: number;
  };

  analysis: {

    clarity: string;

    grammar: string;

    professionalism: string;

    sentiment: string;

    answer_structure: string;
  };

  strengths: string[];

  improvements: string[];

  recruiter_feedback: string;

  hire_recommendation: string;
};


function SpeechIntelligence() {

  const [
    selectedFile,
    setSelectedFile,
  ] = useState<File | null>(null);

  const [
    result,
    setResult,
  ] = useState<SpeechResult | null>(
    null
  );

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState("");

  const [
    isRecording,
    setIsRecording,
  ] = useState(false);

  const [
    recordingSeconds,
    setRecordingSeconds,
  ] = useState(0);

  const mediaRecorderRef =
    useRef<MediaRecorder | null>(null);

  const audioChunksRef =
    useRef<Blob[]>([]);

  const timerRef =
    useRef<number | null>(null);


  async function startRecording() {

    try {

      setError("");

      setResult(null);

      const stream =
        await navigator.mediaDevices.getUserMedia({
          audio: true,
        });

      const mediaRecorder =
        new MediaRecorder(stream);

      mediaRecorderRef.current =
        mediaRecorder;

      audioChunksRef.current = [];

      mediaRecorder.ondataavailable =
        (event) => {

          if (
            event.data.size > 0
          ) {

            audioChunksRef.current.push(
              event.data
            );
          }
        };


      mediaRecorder.onstop = () => {

        const audioBlob =
          new Blob(
            audioChunksRef.current,
            {
              type: "audio/webm",
            }
          );

        const file =
          new File(
            [
              audioBlob,
            ],
            `hiresense-interview-${Date.now()}.webm`,
            {
              type: "audio/webm",
            }
          );

        setSelectedFile(
          file
        );

        stream
          .getTracks()
          .forEach(
            (track) =>
              track.stop()
          );
      };


      mediaRecorder.start();

      setIsRecording(true);

      setRecordingSeconds(0);

      timerRef.current =
        window.setInterval(
          () => {

            setRecordingSeconds(
              (previous) =>
                previous + 1
            );

          },
          1000
        );

    } catch (recordingError) {

      console.error(
        recordingError
      );

      setError(
        "Microphone access failed. Please allow microphone permission."
      );
    }
  }


  function stopRecording() {

    if (
      mediaRecorderRef.current
      &&
      mediaRecorderRef.current.state
      !== "inactive"
    ) {

      mediaRecorderRef.current.stop();
    }

    if (
      timerRef.current
      !== null
    ) {

      window.clearInterval(
        timerRef.current
      );

      timerRef.current = null;
    }

    setIsRecording(false);
  }


  function handleFileChange(
    event:
      React.ChangeEvent<HTMLInputElement>
  ) {

    const file =
      event.target.files?.[0];

    if (!file) {

      return;
    }

    setSelectedFile(
      file
    );

    setResult(null);

    setError("");
  }


  async function runAnalysis() {

    if (!selectedFile) {

      setError(
        "Record or upload an interview response first."
      );

      return;
    }

    try {

      setLoading(true);

      setError("");

      setResult(null);

      const formData =
        new FormData();

      formData.append(
        "file",
        selectedFile
      );

      const data =
        await analyzeSpeech(
          formData
        );

      setResult(
        data
      );

    } catch (analysisError) {

      console.error(
        analysisError
      );

      setError(
        "Speech analysis failed. Check the backend terminal and try again."
      );

    } finally {

      setLoading(false);
    }
  }


  function resetAnalysis() {

    setSelectedFile(null);

    setResult(null);

    setError("");

    setRecordingSeconds(0);
  }


  function formatTime(
    seconds: number
  ) {

    const minutes =
      Math.floor(
        seconds / 60
      );

    const remainingSeconds =
      seconds % 60;

    return `${String(
      minutes
    ).padStart(
      2,
      "0"
    )}:${String(
      remainingSeconds
    ).padStart(
      2,
      "0"
    )}`;
  }


  function scoreColor(
    score: number
  ) {

    if (score >= 85) {

      return "text-green-400";
    }

    if (score >= 70) {

      return "text-cyan-400";
    }

    if (score >= 50) {

      return "text-yellow-400";
    }

    return "text-red-400";
  }


  function scoreBar(
    score: number
  ) {

    if (score >= 85) {

      return "bg-green-400";
    }

    if (score >= 70) {

      return "bg-cyan-400";
    }

    if (score >= 50) {

      return "bg-yellow-400";
    }

    return "bg-red-400";
  }


  return (

    <MainLayout>

      <div
        className="
          max-w-7xl
          mx-auto
          pb-16
        "
      >

        {/* HEADER */}

        <div
          className="
            flex
            flex-col
            xl:flex-row
            xl:items-end
            xl:justify-between
            gap-6
            mb-10
          "
        >

          <div>

            <div
              className="
                inline-flex
                items-center
                gap-2
                px-4
                py-2
                rounded-full
                bg-red-500/10
                border
                border-red-500/20
                text-red-400
                text-sm
                font-bold
                mb-5
              "
            >

              <Sparkles
                size={16}
              />

              AI SPEECH INTELLIGENCE

            </div>

            <h1
              className="
                text-5xl
                md:text-7xl
                font-black
                tracking-tight
                mb-5
              "
            >

              Speak.

              <span
                className="
                  text-red-500
                "
              >
                {" "}
                Get Evaluated.
              </span>

            </h1>

            <p
              className="
                max-w-3xl
                text-lg
                text-zinc-500
                leading-relaxed
              "
            >

              Record an interview answer or
              upload audio. HireSense analyzes
              pacing, filler words, clarity,
              confidence, grammar, and recruiter
              readiness.

            </p>

          </div>


          {
            result && (

              <button
                onClick={
                  resetAnalysis
                }
                className="
                  h-12
                  px-5
                  rounded-2xl
                  bg-white/5
                  border
                  border-white/10
                  hover:border-red-500/30
                  flex
                  items-center
                  gap-2
                  font-bold
                  transition-all
                "
              >

                <RotateCcw
                  size={18}
                />

                New Analysis

              </button>
            )
          }

        </div>


        {/* INPUT AREA */}

        {
          !result && (

            <div
              className="
                grid
                grid-cols-1
                xl:grid-cols-12
                gap-6
                mb-8
              "
            >

              {/* RECORD */}

              <Card
                className="
                  xl:col-span-7
                  p-8
                  relative
                  overflow-hidden
                "
              >

                <div
                  className="
                    absolute
                    top-0
                    right-0
                    w-72
                    h-72
                    bg-red-500/10
                    blur-[100px]
                    rounded-full
                    pointer-events-none
                  "
                />


                <div
                  className="
                    relative
                    z-10
                  "
                >

                  <div
                    className="
                      flex
                      items-center
                      gap-3
                      mb-8
                    "
                  >

                    <div
                      className="
                        w-12
                        h-12
                        rounded-2xl
                        bg-red-500/10
                        flex
                        items-center
                        justify-center
                      "
                    >

                      <Mic
                        className="
                          text-red-400
                        "
                      />

                    </div>

                    <div>

                      <h2
                        className="
                          text-2xl
                          font-black
                        "
                      >
                        Record Interview Answer
                      </h2>

                      <p
                        className="
                          text-zinc-500
                        "
                      >
                        Recommended: 30 to 90 seconds
                      </p>

                    </div>

                  </div>


                  <div
                    className="
                      min-h-[300px]
                      rounded-3xl
                      bg-black/40
                      border
                      border-white/5
                      flex
                      flex-col
                      items-center
                      justify-center
                      text-center
                      p-8
                    "
                  >

                    <div
                      className={`
                        w-32
                        h-32
                        rounded-full
                        flex
                        items-center
                        justify-center
                        mb-8
                        transition-all
                        duration-500

                        ${
                          isRecording
                            ? `
                              bg-red-500/20
                              shadow-[0_0_80px_rgba(239,68,68,0.35)]
                              animate-pulse
                            `
                            : `
                              bg-white/5
                              border
                              border-white/10
                            `
                        }
                      `}
                    >

                      {
                        isRecording

                          ? (

                            <Activity
                              size={50}
                              className="
                                text-red-400
                              "
                            />

                          )

                          : (

                            <Mic
                              size={50}
                              className="
                                text-zinc-400
                              "
                            />
                          )
                      }

                    </div>


                    <div
                      className="
                        text-5xl
                        font-black
                        mb-3
                        tabular-nums
                      "
                    >
                      {
                        formatTime(
                          recordingSeconds
                        )
                      }
                    </div>


                    <p
                      className="
                        text-zinc-500
                        mb-8
                      "
                    >
                      {
                        isRecording
                          ? "Listening to your interview response..."
                          : "Your microphone is ready"
                      }
                    </p>


                    {
                      isRecording

                        ? (

                          <button
                            onClick={
                              stopRecording
                            }
                            className="
                              h-14
                              px-8
                              rounded-2xl
                              bg-white
                              text-black
                              font-black
                              flex
                              items-center
                              gap-3
                              hover:scale-[1.02]
                              transition-all
                            "
                          >

                            <Square
                              size={18}
                              fill="currentColor"
                            />

                            Stop Recording

                          </button>

                        )

                        : (

                          <button
                            onClick={
                              startRecording
                            }
                            className="
                              h-14
                              px-8
                              rounded-2xl
                              bg-red-500
                              hover:bg-red-400
                              font-black
                              flex
                              items-center
                              gap-3
                              shadow-[0_0_40px_rgba(239,68,68,0.2)]
                              transition-all
                            "
                          >

                            <Mic
                              size={20}
                            />

                            Start Recording

                          </button>
                        )
                    }

                  </div>

                </div>

              </Card>


              {/* UPLOAD */}

              <Card
                className="
                  xl:col-span-5
                  p-8
                "
              >

                <div
                  className="
                    flex
                    items-center
                    gap-3
                    mb-8
                  "
                >

                  <div
                    className="
                      w-12
                      h-12
                      rounded-2xl
                      bg-cyan-500/10
                      flex
                      items-center
                      justify-center
                    "
                  >

                    <Upload
                      className="
                        text-cyan-400
                      "
                    />

                  </div>

                  <div>

                    <h2
                      className="
                        text-2xl
                        font-black
                      "
                    >
                      Upload Audio
                    </h2>

                    <p
                      className="
                        text-zinc-500
                      "
                    >
                      MP3, WAV, M4A or WebM
                    </p>

                  </div>

                </div>


                <label
                  className="
                    min-h-[230px]
                    rounded-3xl
                    border
                    border-dashed
                    border-white/10
                    hover:border-cyan-500/40
                    bg-black/30
                    flex
                    flex-col
                    items-center
                    justify-center
                    text-center
                    p-8
                    cursor-pointer
                    transition-all
                  "
                >

                  <FileAudio
                    size={50}
                    className="
                      text-cyan-400
                      mb-5
                    "
                  />

                  <h3
                    className="
                      text-xl
                      font-black
                      mb-2
                    "
                  >
                    Choose Interview Audio
                  </h3>

                  <p
                    className="
                      text-zinc-500
                    "
                  >
                    Click to browse your device
                  </p>

                  <input
                    type="file"
                    accept="
                      audio/*,
                      video/webm,
                      video/mp4
                    "
                    onChange={
                      handleFileChange
                    }
                    className="
                      hidden
                    "
                  />

                </label>


                {
                  selectedFile && (

                    <div
                      className="
                        mt-5
                        p-4
                        rounded-2xl
                        bg-green-500/5
                        border
                        border-green-500/20
                        flex
                        items-center
                        gap-3
                      "
                    >

                      <CheckCircle2
                        className="
                          text-green-400
                          shrink-0
                        "
                        size={20}
                      />

                      <div
                        className="
                          min-w-0
                        "
                      >

                        <p
                          className="
                            font-bold
                            truncate
                          "
                        >
                          {
                            selectedFile.name
                          }
                        </p>

                        <p
                          className="
                            text-sm
                            text-zinc-500
                          "
                        >
                          Ready for AI analysis
                        </p>

                      </div>

                    </div>
                  )
                }


                <button
                  onClick={
                    runAnalysis
                  }
                  disabled={
                    !selectedFile
                    ||
                    loading
                  }
                  className="
                    w-full
                    h-14
                    mt-6
                    rounded-2xl
                    bg-red-500
                    hover:bg-red-400
                    disabled:bg-zinc-800
                    disabled:text-zinc-500
                    disabled:cursor-not-allowed
                    font-black
                    flex
                    items-center
                    justify-center
                    gap-3
                    transition-all
                  "
                >

                  {
                    loading

                      ? (

                        <>

                          <Activity
                            className="
                              animate-spin
                            "
                            size={20}
                          />

                          AI Analysis Running...

                        </>

                      )

                      : (

                        <>

                          <WandSparkles
                            size={20}
                          />

                          Analyze My Speech

                        </>
                      )
                  }

                </button>

              </Card>

            </div>
          )
        }


        {/* ERROR */}

        {
          error && (

            <div
              className="
                mb-8
                p-5
                rounded-2xl
                bg-red-500/10
                border
                border-red-500/20
                flex
                items-center
                gap-3
                text-red-300
              "
            >

              <XCircle
                size={22}
              />

              {error}

            </div>
          )
        }


        {/* LOADING */}

        {
          loading && (

            <Card
              className="
                p-12
                text-center
                mb-8
              "
            >

              <div
                className="
                  w-20
                  h-20
                  rounded-full
                  border-4
                  border-white/10
                  border-t-red-500
                  animate-spin
                  mx-auto
                  mb-6
                "
              />

              <h2
                className="
                  text-3xl
                  font-black
                  mb-3
                "
              >
                AI is analyzing your voice
              </h2>

              <p
                className="
                  text-zinc-500
                "
              >
                Whisper is transcribing your answer
                and Groq is evaluating recruiter-grade
                communication signals.
              </p>

            </Card>
          )
        }


        {/* RESULTS */}

        {
          result && !loading && (

            <div
              className="
                space-y-6
              "
            >

              {/* SCORE CARDS */}

              <div
                className="
                  grid
                  grid-cols-1
                  md:grid-cols-2
                  xl:grid-cols-5
                  gap-5
                "
              >

                {
                  [
                    {
                      label:
                        "Communication",

                      score:
                        result
                          .ai_scores
                          .communication_score,

                      icon:
                        Volume2,
                    },

                    {
                      label:
                        "Confidence",

                      score:
                        result
                          .ai_scores
                          .confidence_score,

                      icon:
                        Gauge,
                    },

                    {
                      label:
                        "Clarity",

                      score:
                        result
                          .ai_scores
                          .clarity_score,

                      icon:
                        Sparkles,
                    },

                    {
                      label:
                        "Grammar",

                      score:
                        result
                          .ai_scores
                          .grammar_score,

                      icon:
                        Brain,
                    },

                    {
                      label:
                        "Professionalism",

                      score:
                        result
                          .ai_scores
                          .professionalism_score,

                      icon:
                        CheckCircle2,
                    },
                  ].map(
                    (item) => {

                      const Icon =
                        item.icon;

                      return (

                        <Card
                          key={
                            item.label
                          }
                          className="
                            p-6
                          "
                        >

                          <Icon
                            className="
                              text-red-400
                              mb-5
                            "
                            size={28}
                          />

                          <div
                            className={`
                              text-4xl
                              font-black
                              mb-2

                              ${
                                scoreColor(
                                  item.score
                                )
                              }
                            `}
                          >
                            {
                              item.score
                            }
                          </div>

                          <p
                            className="
                              text-zinc-500
                              mb-4
                            "
                          >
                            {
                              item.label
                            }
                          </p>

                          <div
                            className="
                              h-1.5
                              rounded-full
                              bg-white/5
                              overflow-hidden
                            "
                          >

                            <div
                              className={`
                                h-full
                                rounded-full

                                ${
                                  scoreBar(
                                    item.score
                                  )
                                }
                              `}
                              style={{
                                width:
                                  `${item.score}%`,
                              }}
                            />

                          </div>

                        </Card>
                      );
                    }
                  )
                }

              </div>


              {/* METRICS */}

              <div
                className="
                  grid
                  grid-cols-2
                  md:grid-cols-4
                  gap-5
                "
              >

                <Card
                  className="
                    p-6
                  "
                >

                  <Clock3
                    className="
                      text-cyan-400
                      mb-4
                    "
                  />

                  <h3
                    className="
                      text-3xl
                      font-black
                    "
                  >
                    {
                      result
                        .speech_metrics
                        .wpm
                    }
                  </h3>

                  <p
                    className="
                      text-zinc-500
                    "
                  >
                    Words Per Minute
                  </p>

                </Card>


                <Card
                  className="
                    p-6
                  "
                >

                  <Activity
                    className="
                      text-yellow-400
                      mb-4
                    "
                  />

                  <h3
                    className="
                      text-3xl
                      font-black
                    "
                  >
                    {
                      result
                        .speech_metrics
                        .filler_words
                    }
                  </h3>

                  <p
                    className="
                      text-zinc-500
                    "
                  >
                    Filler Words
                  </p>

                </Card>


                <Card
                  className="
                    p-6
                  "
                >

                  <Play
                    className="
                      text-green-400
                      mb-4
                    "
                  />

                  <h3
                    className="
                      text-3xl
                      font-black
                    "
                  >
                    {
                      Math.round(
                        result
                          .speech_metrics
                          .duration_seconds
                      )
                    }s
                  </h3>

                  <p
                    className="
                      text-zinc-500
                    "
                  >
                    Speaking Duration
                  </p>

                </Card>


                <Card
                  className="
                    p-6
                  "
                >

                  <FileAudio
                    className="
                      text-purple-400
                      mb-4
                    "
                  />

                  <h3
                    className="
                      text-3xl
                      font-black
                    "
                  >
                    {
                      result
                        .speech_metrics
                        .word_count
                    }
                  </h3>

                  <p
                    className="
                      text-zinc-500
                    "
                  >
                    Total Words
                  </p>

                </Card>

              </div>


              {/* ANALYSIS GRID */}

              <div
                className="
                  grid
                  grid-cols-1
                  xl:grid-cols-12
                  gap-6
                "
              >

                <div
                  className="
                    xl:col-span-7
                    space-y-6
                  "
                >

                  {/* TRANSCRIPT */}

                  <Card
                    className="
                      p-7
                    "
                  >

                    <div
                      className="
                        flex
                        items-center
                        gap-3
                        mb-5
                      "
                    >

                      <FileAudio
                        className="
                          text-cyan-400
                        "
                      />

                      <h2
                        className="
                          text-2xl
                          font-black
                        "
                      >
                        AI Transcript
                      </h2>

                    </div>

                    <p
                      className="
                        text-zinc-300
                        leading-8
                        text-lg
                      "
                    >
                      {
                        result.transcript
                      }
                    </p>

                  </Card>


                  {/* FEEDBACK */}

                  <Card
                    className="
                      p-7
                      relative
                      overflow-hidden
                    "
                  >

                    <div
                      className="
                        absolute
                        top-0
                        right-0
                        w-64
                        h-64
                        bg-red-500/10
                        blur-[100px]
                        rounded-full
                      "
                    />

                    <div
                      className="
                        relative
                        z-10
                      "
                    >

                      <div
                        className="
                          flex
                          items-center
                          gap-3
                          mb-5
                        "
                      >

                        <Brain
                          className="
                            text-red-400
                          "
                        />

                        <h2
                          className="
                            text-2xl
                            font-black
                          "
                        >
                          Recruiter AI Feedback
                        </h2>

                      </div>

                      <p
                        className="
                          text-xl
                          text-zinc-300
                          leading-8
                        "
                      >
                        {
                          result
                            .recruiter_feedback
                        }
                      </p>

                    </div>

                  </Card>

                </div>


                <div
                  className="
                    xl:col-span-5
                    space-y-6
                  "
                >

                  {/* RECOMMENDATION */}

                  <Card
                    className="
                      p-7
                    "
                  >

                    <p
                      className="
                        text-xs
                        text-red-400
                        tracking-[0.25em]
                        font-bold
                        mb-3
                      "
                    >
                      RECRUITER DECISION
                    </p>

                    <h2
                      className="
                        text-4xl
                        font-black
                        mb-6
                      "
                    >
                      {
                        result
                          .hire_recommendation
                      }
                    </h2>


                    <div
                      className="
                        grid
                        grid-cols-2
                        gap-3
                      "
                    >

                      {
                        Object.entries(
                          result.analysis
                        ).map(
                          (
                            [
                              key,
                              value,
                            ]
                          ) => (

                            <div
                              key={
                                key
                              }
                              className="
                                p-4
                                rounded-2xl
                                bg-white/5
                              "
                            >

                              <p
                                className="
                                  text-xs
                                  text-zinc-500
                                  capitalize
                                  mb-1
                                "
                              >
                                {
                                  key.replace(
                                    "_",
                                    " "
                                  )
                                }
                              </p>

                              <p
                                className="
                                  font-bold
                                "
                              >
                                {value}
                              </p>

                            </div>
                          )
                        )
                      }

                    </div>

                  </Card>


                  {/* STRENGTHS */}

                  <Card
                    className="
                      p-7
                    "
                  >

                    <h2
                      className="
                        text-2xl
                        font-black
                        mb-5
                        text-green-400
                      "
                    >
                      Strengths
                    </h2>

                    <div
                      className="
                        space-y-3
                      "
                    >

                      {
                        result
                          .strengths
                          .map(
                            (
                              strength,
                              index
                            ) => (

                              <div
                                key={
                                  index
                                }
                                className="
                                  flex
                                  gap-3
                                  p-4
                                  rounded-2xl
                                  bg-green-500/5
                                  border
                                  border-green-500/10
                                "
                              >

                                <CheckCircle2
                                  className="
                                    text-green-400
                                    shrink-0
                                  "
                                  size={20}
                                />

                                <span>
                                  {strength}
                                </span>

                              </div>
                            )
                          )
                      }

                    </div>

                  </Card>


                  {/* IMPROVEMENTS */}

                  <Card
                    className="
                      p-7
                    "
                  >

                    <h2
                      className="
                        text-2xl
                        font-black
                        mb-5
                        text-yellow-400
                      "
                    >
                      Improvements
                    </h2>

                    <div
                      className="
                        space-y-3
                      "
                    >

                      {
                        result
                          .improvements
                          .map(
                            (
                              improvement,
                              index
                            ) => (

                              <div
                                key={
                                  index
                                }
                                className="
                                  flex
                                  gap-3
                                  p-4
                                  rounded-2xl
                                  bg-yellow-500/5
                                  border
                                  border-yellow-500/10
                                "
                              >

                                <Sparkles
                                  className="
                                    text-yellow-400
                                    shrink-0
                                  "
                                  size={20}
                                />

                                <span>
                                  {
                                    improvement
                                  }
                                </span>

                              </div>
                            )
                          )
                      }

                    </div>

                  </Card>

                </div>

              </div>

            </div>
          )
        }

      </div>

    </MainLayout>
  );
}


export default SpeechIntelligence;