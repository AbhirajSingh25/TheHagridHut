import {
  motion,
  useScroll,
  useSpring,
  useMotionValue,
} from "framer-motion";
import { Link } from "react-router-dom";

const features = [
  {
    title: "AI Interviews",
    desc: "Real-time AI mock interviews with dynamic follow-up questions.",
  },
  {
    title: "Resume Analyzer",
    desc: "ATS score, recruiter feedback and skill gap analysis.",
  },
  {
    title: "JD Matcher",
    desc: "Compare resumes against job descriptions instantly.",
  },
  {
    title: "Recruiter Dashboard",
    desc: "Track and evaluate candidate performance using AI insights.",
  },
  {
    title: "Certificates",
    desc: "Generate professional interview achievement certificates.",
  },
  {
    title: "Hiring Prediction",
    desc: "Estimate hiring probability using interview performance.",
  },
];

const testimonials = [
  {
    text: "The closest experience to a real interview.",
    role: "Software Engineer",
  },
  {
    text: "ATS analysis helped me land interviews.",
    role: "Data Analyst",
  },
  {
    text: "Better than most mock interview platforms.",
    role: "Backend Developer",
  },
];

  

function Landing() {
  const { scrollYProgress } =
  useScroll();
const mouseX =
  useMotionValue(0);

const mouseY =
  useMotionValue(0);
const scaleX =
  useSpring(
    scrollYProgress,
    {
      stiffness: 100,
      damping: 30,
    }
  );
  return (
    <div
  onMouseMove={(e) => {

    mouseX.set(
      e.clientX - 200
    );

    mouseY.set(
      e.clientY - 200
    );

  }}

  className="
    min-h-screen
    bg-black
    text-white
    overflow-hidden
  "
>
  <motion.div
  className="
    fixed
    w-[400px]
    h-[400px]
    rounded-full
    bg-red-500/10
    blur-[150px]
    pointer-events-none
    z-0
  "

  style={{
    x: mouseX,
    y: mouseY,
  }}
/>
<motion.div
  style={{
    scaleX,
    transformOrigin:
      "left",
  }}
  className="
    fixed
    top-0
    left-0
    right-0
    h-1
    bg-red-500
    z-[100]
  "
/>

      {/* NAVBAR */}

      <nav
        className="
          fixed
          top-0
          left-0
          right-0
          z-50
          px-10
          py-6
          flex
          justify-between
          items-center
          backdrop-blur-xl
          bg-black/30
          border-b
          border-white/5
        "
      >
        <h1
          className="
            text-3xl
            font-black
            text-red-500
          "
        >
          HireSense AI
        </h1>

        <div className="flex gap-6 items-center">
          <Link
            to="/login"
            className="hover:text-red-400"
          >
            Login
          </Link>

          <Link
            to="/signup"
            className="
              px-5
              py-2
              rounded-xl
              bg-red-500
              hover:bg-red-400
              transition-all
            "
          >
            Get Started
          </Link>
        </div>
      </nav>

      {/* HERO */}

      <section
      
        className="
          relative
          min-h-screen
          flex
          items-center
          justify-center
          px-6
        "
      >
        <div
  className="
    absolute
    inset-0
    opacity-10
  "
  style={{
    backgroundImage: `
      linear-gradient(
        rgba(255,255,255,.08) 1px,
        transparent 1px
      ),
      linear-gradient(
        90deg,
        rgba(255,255,255,.08) 1px,
        transparent 1px
      )
    `,
    backgroundSize: "80px 80px",
  }}
/>
<section
  className="
    overflow-hidden
    py-16
  "
>
  <motion.div
    animate={{
      x:["0%","-100%"]
    }}
    transition={{
      duration:25,
      repeat:Infinity,
      ease:"linear"
    }}
    className="
      flex
      gap-24
      whitespace-nowrap
      text-5xl
      font-black
      text-zinc-700
    "
  >
    <span>AI INTERVIEWS</span>
    <span>ATS ANALYSIS</span>
    <span>JD MATCHING</span>
    <span>RECRUITER AI</span>
    <span>AI COPILOT</span>
    <span>HIRING INTELLIGENCE</span>
  </motion.div>
</section>
        {/* BLOBS */}

        <motion.div
          animate={{
            x: [0, 50, 0],
            y: [0, -50, 0],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
          }}
          className="
            absolute
            top-20
            left-10
            w-96
            h-96
            bg-red-500/20
            blur-[120px]
            rounded-full
          "
        />

        <motion.div
          animate={{
            x: [0, -40, 0],
            y: [0, 60, 0],
          }}
          transition={{
            duration: 14,
            repeat: Infinity,
          }}
          className="
            absolute
            bottom-20
            right-10
            w-96
            h-96
            bg-cyan-500/20
            blur-[120px]
            rounded-full
          "
        />

        <motion.div
          animate={{
            x: [0, 30, 0],
            y: [0, -30, 0],
          }}
          transition={{
            duration: 16,
            repeat: Infinity,
          }}
          className="
            absolute
            top-1/2
            left-1/2
            -translate-x-1/2
            -translate-y-1/2
            w-[500px]
            h-[500px]
            bg-purple-500/10
            blur-[160px]
            rounded-full
          "
        />

        <div
          className="
            absolute
            inset-0
            bg-gradient-to-br
            from-red-500/10
            via-transparent
            to-cyan-500/10
          "
        />
<motion.div
  animate={{
    y:[0,-20,0]
  }}
  transition={{
    duration:4,
    repeat:Infinity
  }}
  className="
    absolute
    left-20
    top-40
    p-5
    rounded-3xl
    bg-white/5
    backdrop-blur-xl
    border
    border-white/10
  "
>
  ATS Score 95%
</motion.div>

<motion.div
  animate={{
    y:[0,20,0]
  }}
  transition={{
    duration:5,
    repeat:Infinity
  }}
  className="
    absolute
    right-20
    top-60
    p-5
    rounded-3xl
    bg-white/5
    backdrop-blur-xl
    border
    border-white/10
  "
>
  Recruiter Approved
</motion.div>

<motion.div
  animate={{
    y:[0,-15,0]
  }}
  transition={{
    duration:6,
    repeat:Infinity
  }}
  className="
    absolute
    left-32
    bottom-32
    p-5
    rounded-3xl
    bg-white/5
    backdrop-blur-xl
    border
    border-white/10
  "
>
  AI Confidence 92%
</motion.div>
        <motion.div
          initial={{
            opacity: 0,
            y: 50,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          transition={{
            duration: 0.8,
          }}
          className="
            text-center
            z-10
            max-w-6xl
          "
        >
          <h1
            className="
              text-6xl
              md:text-8xl
              font-black
              mb-6
              leading-tight
            "
          >
            AI That Understands
            <br />

            <span className="text-red-500">
              Talent.
            </span>

            Instantly.
          </h1>

          <p
            className="
              text-xl
              md:text-2xl
              text-zinc-400
              max-w-3xl
              mx-auto
            "
          >
            AI Powered Interview Copilot,
            Resume Analyzer,
            Recruiter Intelligence Platform
          </p>

          <div
            className="
              flex
              flex-wrap
              justify-center
              gap-5
              mt-10
            "
          >
            <Link
              to="/signup"
              className="
                px-8
                py-4
                rounded-2xl
                bg-red-500
                hover:bg-red-400
                font-bold
                transition-all
              "
            >
              Start Free Interview
            </Link>

            <Link
              to="/resume-analyzer"
              className="
                px-8
                py-4
                rounded-2xl
                border
                border-white/10
                hover:border-white/30
                font-bold
                transition-all
              "
            >
              Analyze Resume
            </Link>
          </div>
        </motion.div>
      </section>

      {/* STATS */}

      <section
        className="
          py-20
          px-10
        "
      >
        <div
          className="
            max-w-7xl
            mx-auto
            grid
            md:grid-cols-4
            gap-8
          "
        >
          <div className="text-center">
            <h2 className="text-5xl font-black text-red-400">
              10,000+
            </h2>
            <p>Interviews Completed</p>
          </div>

          <div className="text-center">
            <h2 className="text-5xl font-black text-cyan-400">
              25,000+
            </h2>
            <p>ATS Reports Generated</p>
          </div>

          <div className="text-center">
            <h2 className="text-5xl font-black text-green-400">
              95%
            </h2>
            <p>ATS Accuracy</p>
          </div>

          <div className="text-center">
            <h2 className="text-5xl font-black text-purple-400">
              24/7
            </h2>
            <p>AI Evaluation</p>
          </div>
        </div>
      </section>

      {/* FEATURES */}

      <section
        className="
          py-24
          px-10
        "
      >
        <div
          className="
            max-w-7xl
            mx-auto
          "
        >
          <h2
            className="
              text-6xl
              font-black
              text-center
              mb-16
            "
          >
            Powerful Features
          </h2>

          <div
            className="
              grid
              md:grid-cols-3
              gap-8
            "
          >
            {features.map((feature) => (
              <motion.div
                key={feature.title}
                whileHover={{
                  scale: 1.05,
                  y: -10,
                }}
                className="
                  p-8
                  rounded-3xl
                  bg-white/5
                  border
                  border-white/10
                "
              >
                <h3
                  className="
                    text-2xl
                    font-bold
                    mb-4
                  "
                >
                  {feature.title}
                </h3>

                <p className="text-zinc-400">
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}

      <section
        className="
          py-24
          px-10
        "
      >
        <h2
          className="
            text-6xl
            font-black
            text-center
            mb-16
          "
        >
          Trusted By Candidates
        </h2>

        <div
          className="
            max-w-7xl
            mx-auto
            grid
            md:grid-cols-3
            gap-8
          "
        >
          {testimonials.map((item, index) => (
            <div
              key={index}
              className="
                p-8
                rounded-3xl
                bg-white/5
                border
                border-white/10
              "
            >
              <p className="text-lg">
                "{item.text}"
              </p>

              <div
                className="
                  mt-5
                  text-red-400
                  font-semibold
                "
              >
                {item.role}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}

      <section
        className="
          py-32
          text-center
          px-6
        "
      >
        <h2
          className="
            text-6xl
            font-black
            mb-6
          "
        >
          Ready To Get Hired?
        </h2>

        <p
          className="
            text-zinc-500
            mb-10
            text-xl
          "
        >
          Start practicing with AI today.
        </p>

        <Link
          to="/signup"
          className="
            px-10
            py-5
            bg-red-500
            rounded-2xl
            font-bold
            hover:bg-red-400
            transition-all
          "
        >
          Start Free
        </Link>
      </section>
    </div>
  );
}

export default Landing;