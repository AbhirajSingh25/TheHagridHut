import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import {
  useAuth,
} from "./context/AuthContext";
import CandidateIntelligence
from "./pages/CandidateIntelligence";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

import Dashboard from "./pages/Dashboard";
import ResumeAnalyzer from "./pages/ResumeAnalyzer";
import LiveInterview from "./pages/LiveInterview";
import PracticeMode from "./pages/PracticeMode";
import Analytics from "./pages/Analytics";
import Reports from "./pages/Reports";
import Leaderboard from "./pages/Leaderboard";
import RecruiterDashboard from "./pages/RecruiterDashboard";
import AICopilot from "./pages/AICopilot";
import Settings from "./pages/Settings";

import Certificate from "./pages/Certificate";
import Achievements from "./pages/Achievements";
import JDMatcher from "./pages/JDMatcher";
import AdminPanel from "./pages/AdminPanel";
import HiringProbability from "./pages/HiringProbability";
import InterviewPlayback from "./pages/InterviewPlayback";

import SpeechIntelligence from "./pages/SpeechIntelligence";


function ProtectedRoute({
  children,
}: {
  children: React.ReactNode;
}) {

  const {
    isAuthenticated,
  } = useAuth();


  if (!isAuthenticated) {

    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }


  return children;
}


function PublicRoute({
  children,
}: {
  children: React.ReactNode;
}) {

  const {
    isAuthenticated,
  } = useAuth();


  if (isAuthenticated) {

    return (
      <Navigate
        to="/dashboard"
        replace
      />
    );
  }


  return children;
}


function App() {

  return (

    <BrowserRouter>

      <Routes>

        {/* ================================
            PUBLIC ROUTES
        ================================= */}

        <Route
          path="/"
          element={
            <Landing />
          }
        />


        <Route
          path="/login"
          element={
            <PublicRoute>

              <Login />

            </PublicRoute>
          }
        />

<Route
  path="/candidate-intelligence"
  element={
    <ProtectedRoute>
      <CandidateIntelligence />
    </ProtectedRoute>
  }
/>
        <Route
          path="/signup"
          element={
            <PublicRoute>

              <Signup />

            </PublicRoute>
          }
        />


        {/* ================================
            DASHBOARD
        ================================= */}

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>

              <Dashboard />

            </ProtectedRoute>
          }
        />


        {/* ================================
            RESUME INTELLIGENCE
        ================================= */}

        <Route
          path="/resume-analyzer"
          element={
            <ProtectedRoute>

              <ResumeAnalyzer />

            </ProtectedRoute>
          }
        />


        <Route
          path="/jd-matcher"
          element={
            <ProtectedRoute>

              <JDMatcher />

            </ProtectedRoute>
          }
        />


        {/* ================================
            INTERVIEW SYSTEM
        ================================= */}

        <Route
          path="/live-interview"
          element={
            <ProtectedRoute>

              <LiveInterview />

            </ProtectedRoute>
          }
        />


        <Route
          path="/practice"
          element={
            <ProtectedRoute>

              <PracticeMode />

            </ProtectedRoute>
          }
        />


        <Route
          path="/playback/:id"
          element={
            <ProtectedRoute>

              <InterviewPlayback />

            </ProtectedRoute>
          }
        />


        {/* ================================
            SPEECH INTELLIGENCE
        ================================= */}

        <Route
          path="/speech-intelligence"
          element={
            <ProtectedRoute>

              <SpeechIntelligence />

            </ProtectedRoute>
          }
        />


        {/* ================================
            ANALYTICS
        ================================= */}

        <Route
          path="/analytics"
          element={
            <ProtectedRoute>

              <Analytics />

            </ProtectedRoute>
          }
        />


        <Route
          path="/hiring-probability"
          element={
            <ProtectedRoute>

              <HiringProbability />

            </ProtectedRoute>
          }
        />


        {/* ================================
            REPORTS
        ================================= */}

        <Route
          path="/reports"
          element={
            <ProtectedRoute>

              <Reports />

            </ProtectedRoute>
          }
        />


        <Route
          path="/certificate"
          element={
            <ProtectedRoute>

              <Certificate />

            </ProtectedRoute>
          }
        />


        <Route
          path="/achievements"
          element={
            <ProtectedRoute>

              <Achievements />

            </ProtectedRoute>
          }
        />


        {/* ================================
            RECRUITER INTELLIGENCE
        ================================= */}

        <Route
          path="/recruiter"
          element={
            <ProtectedRoute>

              <RecruiterDashboard />

            </ProtectedRoute>
          }
        />


        <Route
          path="/leaderboard"
          element={
            <ProtectedRoute>

              <Leaderboard />

            </ProtectedRoute>
          }
        />


        {/* ================================
            AI COPILOT
        ================================= */}

        <Route
          path="/copilot"
          element={
            <ProtectedRoute>

              <AICopilot />

            </ProtectedRoute>
          }
        />


        {/* ================================
            ADMIN
        ================================= */}

        <Route
          path="/admin"
          element={
            <ProtectedRoute>

              <AdminPanel />

            </ProtectedRoute>
          }
        />


        {/* ================================
            SETTINGS
        ================================= */}

        <Route
          path="/settings"
          element={
            <ProtectedRoute>

              <Settings />

            </ProtectedRoute>
          }
        />


        {/* ================================
            FALLBACK
        ================================= */}

        <Route
          path="*"
          element={
            <Navigate
              to="/dashboard"
              replace
            />
          }
        />

      </Routes>

    </BrowserRouter>
  );
}


export default App;